package com.example.locoveer.Sign

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.locoveer.MainActivity
import com.example.locoveer.R
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class ScreenPreference : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screen_preference)

        // Mendapatkan referensi dari XML
        val chipGroup = findViewById<ChipGroup>(R.id.chipGroup)
        val buttonSave = findViewById<Button>(R.id.buttonsave)

        // Menyimpan daftar destinasi yang dipilih
        val selectedDestinations = mutableListOf<String>()

        // Looping melalui setiap Chip dalam ChipGroup
        for (i in 0 until chipGroup.childCount) {
            val chip = chipGroup.getChildAt(i) as Chip

            // Listener untuk setiap Chip
            chip.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    selectedDestinations.add(chip.text.toString())
                    Log.d("ScreenPreference", "${chip.text} selected")
                } else {
                    selectedDestinations.remove(chip.text.toString())
                    Log.d("ScreenPreference", "${chip.text} deselected")
                }
            }
        }

        // Aksi ketika tombol Save diklik
        buttonSave.setOnClickListener {
            if (selectedDestinations.isNotEmpty()) {
                val selectedText = selectedDestinations.joinToString(", ")
                Toast.makeText(this, "Selected Destinations: $selectedText", Toast.LENGTH_SHORT).show()

                // Pindah ke halaman MainActivity
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Please select at least one destination", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
