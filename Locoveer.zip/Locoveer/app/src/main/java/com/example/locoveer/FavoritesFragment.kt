package com.example.locoveer

import androidx.fragment.app.Fragment

class FavoritesFragment : Fragment(R.layout.fragment_favorite){
}