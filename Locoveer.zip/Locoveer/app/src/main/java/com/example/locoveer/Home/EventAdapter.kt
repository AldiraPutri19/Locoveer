package com.example.locoveer.Home

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.locoveer.R

class EventAdapter(private val items: List<PlaceItem>) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    // ViewHolder untuk setiap item di RecyclerView
    class EventViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val eventImage: ImageView = view.findViewById(R.id.eventImage)
        val locationTag: TextView = view.findViewById(R.id.locationTag)
        val eventTitle: TextView = view.findViewById(R.id.eventTitle)
        val eventRating: TextView = view.findViewById(R.id.eventRating)
        val eventReviews: TextView = view.findViewById(R.id.eventReviews)
        val eventDescription: TextView = view.findViewById(R.id.eventDescription)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.home_event_list, parent, false)
        return EventViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val item = items[position]

        // Set data pada ViewHolder
        holder.eventImage.setImageResource(item.imageResId)
        holder.eventTitle.text = item.title
        holder.eventDescription.text = item.description

        // Tambahkan listener untuk klik item
        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, DetailActivity::class.java).apply {
                putExtra("EXTRA_IMAGE", item.imageResId)
                putExtra("EXTRA_TITLE", item.title)
                putExtra("EXTRA_DESCRIPTION", item.description)
            }
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = items.size
}
