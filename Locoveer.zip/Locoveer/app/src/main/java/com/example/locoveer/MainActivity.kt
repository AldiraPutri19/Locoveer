package com.example.locoveer

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.example.locoveer.Home.HomeFragment
import com.example.locoveer.Explore.CompassFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottomNavigationView)

        // Set fragment default ke Home setelah login
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.frameLayout, HomeFragment())  // Memuat HomeFragment sebagai fragment default
                .commit()
        }

        // Menangani pemilihan item di BottomNavigationView
        bottomNavigationView.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.Home -> HomeFragment()
                R.id.Explore -> CompassFragment()
                R.id.favorites -> FavoritesFragment()
                R.id.Settings -> SettingsFragment()
                else -> throw IllegalStateException("Item ID tidak dikenal")
            }

            // Ganti fragment di FrameLayout
            supportFragmentManager.beginTransaction()
                .replace(R.id.frameLayout, fragment)
                .commit()

            true  // Menandakan item sudah dipilih
        }
    }
}
