package com.example.locoveer.Home

data class PlaceItem(
    val imageResId: Int,
    val title: String,
    val description: String
)
