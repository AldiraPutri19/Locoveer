package com.example.locoveer.Home

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.locoveer.R

class HomeFragment : Fragment(R.layout.fragment_home) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Dummy data untuk RecyclerView Horizontal
        val dummyMainItems = listOf(
            PlaceItem(R.drawable.cth1, "Taman Mini Indonesia Indah", "Cultural park showcasing Indonesia's heritage."),
            PlaceItem(R.drawable.cth1, "Ragunan Zoo", "A zoo with diverse animals."),
            PlaceItem(R.drawable.cth1, "National Monument", "Iconic symbol of Indonesia.")
        )

        // RecyclerView Horizontal (rvMain)
        val rvMain: RecyclerView = view.findViewById(R.id.rvMain)
        rvMain.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        rvMain.adapter = EventAdapter(dummyMainItems)

        // Dummy data untuk RecyclerView Vertikal
        val dummyInactiveItems = listOf(
            PlaceItem(R.drawable.cth2, "Tanah Lot", "A beautiful seaside temple."),
            PlaceItem(R.drawable.cth2, "Ubud Monkey Forest", "A natural sanctuary."),
            PlaceItem(R.drawable.cth2, "Tegenungan Waterfall", "A magnificent waterfall.")
        )

        // RecyclerView Vertikal (rvInactive)
        val rvInactive: RecyclerView = view.findViewById(R.id.rvInactive)
        rvInactive.layoutManager = LinearLayoutManager(requireContext())
        rvInactive.adapter = PlaceAdapter(dummyInactiveItems)
    }
}
