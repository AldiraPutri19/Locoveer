package com.example.locoveer.Sign

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.locoveer.R

class LoginScreenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_login_screen) // Sesuaikan dengan layout Anda

        val signUpButton: Button = findViewById(R.id.button)
        val signInButton: Button = findViewById(R.id.button2)

        // Ambil data dari ScreenPreference (jika ada)
        val selectedDestinations = intent.getStringExtra("selected_destinations")
        if (!selectedDestinations.isNullOrEmpty()) {
            Toast.makeText(this, "Selected destinations: $selectedDestinations", Toast.LENGTH_LONG)
                .show()
        }

        signUpButton.setOnClickListener {
            // Pindah ke Activity CreateAccount
            val intent = Intent(this, CreateAccountActivity::class.java)
            startActivity(intent)
        }

        signInButton.setOnClickListener {
            // Pindah ke Activity SignIn
            val intent = Intent(this, SignIn::class.java)
            startActivity(intent)
        }
    }
}
