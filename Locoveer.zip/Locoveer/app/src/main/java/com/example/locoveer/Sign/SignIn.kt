package com.example.locoveer.Sign

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.locoveer.MainActivity  // Import MainActivity
import com.example.locoveer.R

class SignIn : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_sign_in)

        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.button5)

        btnLogin.setOnClickListener {
            val emailInput = etEmail.text.toString().trim()
            val passwordInput = etPassword.text.toString()

            // Ambil data dari SharedPreferences
            val registeredEmail = sharedPreferences.getString("email", null)
            val registeredPassword = sharedPreferences.getString("password", null)

            if (emailInput.isEmpty() || passwordInput.isEmpty()) {
                Toast.makeText(this, "Email dan Password tidak boleh kosong!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            // Cek jika email ditemukan dan password benar
            if (emailInput == registeredEmail) {
                if (passwordInput == registeredPassword) {
                    // Jika login berhasil
                    Toast.makeText(this, "Login berhasil!", Toast.LENGTH_SHORT).show()

                    // Pindah ke halaman ScreenPreference
                    val intent = Intent(this, ScreenPreference::class.java)
                    startActivity(intent)
                    finish() // Tutup halaman login agar tidak bisa kembali
                } else {
                    // Jika password salah
                    Toast.makeText(this, "Password salah!", Toast.LENGTH_SHORT).show()
                }
            } else {
                // Jika email tidak ditemukan
                Toast.makeText(this, "Email tidak ditemukan!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
