package com.example.locoveer.Explore

import androidx.fragment.app.Fragment
import com.example.locoveer.R

class CompassFragment : Fragment(R.layout.fragment_explore){
}