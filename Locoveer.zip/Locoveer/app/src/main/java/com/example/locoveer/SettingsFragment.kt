package com.example.locoveer

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import android.view.View
import android.widget.Button
import android.widget.Switch
import com.example.locoveer.Sign.LoginScreenActivity

class SettingsFragment : Fragment(R.layout.fragment_setting) {

    private lateinit var themePreferences: ThemePreferences

    override fun onAttach(context: Context) {
        super.onAttach(context)
        themePreferences = ThemePreferences(context)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val switchDarkMode = view.findViewById<Switch>(R.id.switchDarkMode)
        val btnLogout = view.findViewById<Button>(R.id.btn_logout)

        // Mengatur tema berdasarkan preferensi saat ini
        lifecycleScope.launch {
            themePreferences.darkMode.collect { isDarkMode ->
                switchDarkMode.isChecked = isDarkMode
                AppCompatDelegate.setDefaultNightMode(
                    if (isDarkMode) AppCompatDelegate.MODE_NIGHT_YES
                    else AppCompatDelegate.MODE_NIGHT_NO
                )
            }
        }

        // Menyimpan preferensi saat switch diubah
        switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            lifecycleScope.launch {
                themePreferences.saveDarkMode(isChecked)
            }
        }

        // Navigasi ke halaman login saat tombol logout ditekan
        btnLogout.setOnClickListener {
            logout()
        }
    }

    private fun logout() {
        // Hapus sesi/token dari SharedPreferences
        val sharedPref = requireActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE)
        sharedPref.edit().clear().apply()

        // Pindah ke halaman login
        val intent = Intent(requireContext(), LoginScreenActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
    }
}
