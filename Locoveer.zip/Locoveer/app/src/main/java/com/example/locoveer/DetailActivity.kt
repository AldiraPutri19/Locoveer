package com.example.locoveer.Home

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.locoveer.R

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        // Ambil data dari Intent
        val imageResId = intent.getIntExtra("EXTRA_IMAGE", 0)
        val title = intent.getStringExtra("EXTRA_TITLE")
        val description = intent.getStringExtra("EXTRA_DESCRIPTION")

        // Inisialisasi UI
        val detailImage: ImageView = findViewById(R.id.iv_detail_image)
        val detailTitle: TextView = findViewById(R.id.tv_detail_title)
        val detailDescription: TextView = findViewById(R.id.tv_detail_description)
        val actionButton: Button = findViewById(R.id.btn_action)

        // Set data ke UI
        detailImage.setImageResource(imageResId)
        detailTitle.text = title
        detailDescription.text = description

        // Tambahkan aksi tombol
        actionButton.setOnClickListener {
            // Tambahkan logika aksi tombol di sini
        }
    }
}
